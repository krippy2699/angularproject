import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuitems',
  templateUrl: './menuitems.component.html',
  styleUrls: ['./menuitems.component.css']
})
export class MenuitemsComponent implements OnInit {



  constructor() {}

  ngOnInit(): void {
  }

  public addmenuitem()
  {
  
  }


}
