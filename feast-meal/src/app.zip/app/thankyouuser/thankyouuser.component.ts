import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thankyouuser',
  templateUrl: './thankyouuser.component.html',
  styleUrls: ['./thankyouuser.component.css']
})
export class ThankyouuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
